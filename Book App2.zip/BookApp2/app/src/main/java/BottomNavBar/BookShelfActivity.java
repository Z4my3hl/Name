package BottomNavBar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp2.HomeActivity;
import com.example.bookapp2.R;

public class BookShelfActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bookshelfscreen);

        ImageButton backButton = findViewById(R.id.back_button);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create and start the intent
                Intent intent = new Intent(BookShelfActivity.this, HomeActivity.class);
                startActivity(intent);
                finish(); // close current screen so user can't go back
            }
        });
    }
}


