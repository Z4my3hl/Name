package BottomNavBar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp2.HomeActivity;
import com.example.bookapp2.R;

import java.io.IOException;

public class ProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView profilePicture;
    private TextView usernameView, bioView;
    private String username = "Default User", bio = "No bio yet.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilescreen);

        profilePicture = findViewById(R.id.profile_picture);
        usernameView = findViewById(R.id.username);
        bioView = findViewById(R.id.bio);

        usernameView.setText(username);
        bioView.setText(bio);

        ImageButton backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });

        Button editBtn = findViewById(R.id.edit_profile_button);
        editBtn.setOnClickListener(v -> showEditDialog());
    }

    private void showEditDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Profile");

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_edit_profile, null);

        if (dialogView != null) {
            EditText editUsername = dialogView.findViewById(R.id.edit_username);
            EditText editBio = dialogView.findViewById(R.id.edit_bio);
            Button changePictureBtn = dialogView.findViewById(R.id.change_picture_button);

            if (editUsername != null && editBio != null && changePictureBtn != null) {
                editUsername.setText(username);
                editBio.setText(bio);

                changePictureBtn.setOnClickListener(v -> pickImageFromGallery());

                builder.setView(dialogView);
                builder.setPositiveButton("Save", (dialog, which) -> {
                    username = editUsername.getText().toString();
                    bio = editBio.getText().toString();
                    usernameView.setText(username);
                    bioView.setText(bio);
                });
                builder.setNegativeButton("Cancel", null);
                builder.show();
            }
        }
    }

    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();

            // Clean up old bitmap if necessary
            if (profilePicture.getDrawable() instanceof BitmapDrawable) {
                BitmapDrawable drawable = (BitmapDrawable) profilePicture.getDrawable();
                Bitmap oldBitmap = drawable.getBitmap();
                if (oldBitmap != null && !oldBitmap.isRecycled()) {
                    oldBitmap.recycle();
                }
            }

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                profilePicture.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

