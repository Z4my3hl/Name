package BottomNavBar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.bookapp2.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bookapp2.HomeActivity;

public class PublishActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    EditText titleEditText, authorEditText, contentEditText;
    Spinner genreSpinner;
    Button uploadCoverButton, publishButton;
    ImageView coverPreview;
    Uri selectedImageUri; // for storing image URI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.publishscreen);

        // Find views by ID
        titleEditText = findViewById(R.id.book_title);
        authorEditText = findViewById(R.id.author_name);
        contentEditText = findViewById(R.id.book_content);
        genreSpinner = findViewById(R.id.genre_spinner);
        uploadCoverButton = findViewById(R.id.upload_cover_button);
        coverPreview = findViewById(R.id.cover_preview);
        publishButton = findViewById(R.id.publish_button);
        ImageButton backButton = findViewById(R.id.back_button);

        // Spinner items (genre list)
        String[] genres = {"Fantasy", "Romance", "Horror", "Science Fiction", "Mystery", "Adventure"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, genres);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genreSpinner.setAdapter(adapter);

        // Back button behavior
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PublishActivity.this, HomeActivity.class); // navigate to HomeActivity
                startActivity(intent);
                finish(); // finish current activity so user can't go back here
            }
        });

        // Upload cover button behavior
        uploadCoverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageChooser();
            }
        });

        // Publish button behavior
        publishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString();
                String author = authorEditText.getText().toString();
                String genre = genreSpinner.getSelectedItem().toString();
                String content = contentEditText.getText().toString();

                if (title.isEmpty() || author.isEmpty() || content.isEmpty()) {
                    Toast.makeText(PublishActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // For now, just show a toast
                Toast.makeText(PublishActivity.this, "Book published successfully!", Toast.LENGTH_LONG).show();

                // Optionally: go back to home screen
                Intent intent = new Intent(PublishActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    // Method to open image picker
    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Cover Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            coverPreview.setImageURI(selectedImageUri);
            coverPreview.setVisibility(View.VISIBLE);
        }
    }
}

