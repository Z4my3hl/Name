    package com.example.bookapp2;
    import android.os.Bundle;

    import androidx.appcompat.app.AppCompatActivity;
    import android.content.Intent;
    import android.view.View;
    import android.widget.ImageButton;

    import BottomNavBar.BookShelfActivity;
    import BottomNavBar.ProfileActivity;
    import BottomNavBar.PublishActivity;

    public class HomeActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.homescreen);

            ImageButton publishButton = findViewById(R.id.nav_publish);
            ImageButton profileButton = findViewById(R.id.nav_profile);
            ImageButton bookshelfButton = findViewById(R.id.nav_bookshelf);

            publishButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(HomeActivity.this, PublishActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            profileButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            bookshelfButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(HomeActivity.this, BookShelfActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
        }
    }
